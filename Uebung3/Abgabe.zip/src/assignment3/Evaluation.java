package assignment3;

public class Evaluation {
	public static long[] minSum(int[] q, long[] m, long[] z) {
		return null;
	}
}
